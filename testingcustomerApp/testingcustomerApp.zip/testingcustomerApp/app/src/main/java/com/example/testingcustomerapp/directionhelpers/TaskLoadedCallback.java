package com.example.testingcustomerapp.directionhelpers;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
