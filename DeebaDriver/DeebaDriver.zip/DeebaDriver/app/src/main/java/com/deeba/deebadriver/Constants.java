package com.deeba.deebadriver;

public class Constants {

    public static final String ROOT_URL="http://18.191.245.16/deeba/";
    public static final String OBJECT_URL = ROOT_URL + "index.php/Andriod/object";
    public static final String update = ROOT_URL + "index.php/Andriod/update";
    public static final String distance = ROOT_URL + "index.php/Andriod/getGoogle";


}

