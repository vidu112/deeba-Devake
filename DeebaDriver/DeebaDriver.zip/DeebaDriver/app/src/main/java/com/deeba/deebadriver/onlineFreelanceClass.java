package com.deeba.deebadriver;

public class onlineFreelanceClass {
    private String Date;
    private String Time;
    private String CustomerId;
    private String CustomerLat;
    private String CustomerLon;
    private String DriverId;
    private String Lat;
    private String Lon;
    private String status;

    public onlineFreelanceClass() {

    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getCustomerId() {
        return CustomerId;
    }

    public void setCustomerId(String customerId) {
        CustomerId = customerId;
    }

    public String getCustomerLat() {
        return CustomerLat;
    }

    public void setCustomerLat(String customerLat) {
        CustomerLat = customerLat;
    }

    public String getCustomerLon() {
        return CustomerLon;
    }

    public void setCustomerLon(String customerLon) {
        CustomerLon = customerLon;
    }

    public String getDriverId() {
        return DriverId;
    }

    public void setDriverId(String driverId) {
        DriverId = driverId;
    }

    public String getLat() {
        return Lat;
    }

    public void setLat(String lat) {
        Lat = lat;
    }

    public String getLon() {
        return Lon;
    }

    public void setLon(String lon) {
        Lon = lon;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
