package com.deeba.deebadriver;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Pricing extends AppCompatActivity {
    TextView TotalDistanceText,TotalTimeText,TotalPriceText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pricing);
        TotalDistanceText=(TextView)findViewById(R.id.total_distance);
        TotalTimeText=(TextView)findViewById(R.id.total_waiting);
        TotalPriceText=(TextView)findViewById(R.id.total_price);
        String Total_Distance=getIntent().getStringExtra("TotalDistance")+"Km";
        String Total_Time=getIntent().getStringExtra("TotalTime")+"s";
        String Total_Price=getIntent().getStringExtra("TotalPrice")+" LKR";
        TotalDistanceText.setText(Total_Distance);
        TotalTimeText.setText(Total_Time);
        TotalPriceText.setText(Total_Price);
    }
    public void Confirm_Payment(View view){
        Intent FreMapActivity = new Intent(getApplicationContext(), FreMapActivity.class);
        startActivity(FreMapActivity);
    }
}
