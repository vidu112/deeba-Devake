package com.deeba.deebadriver.directionhelpers;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
